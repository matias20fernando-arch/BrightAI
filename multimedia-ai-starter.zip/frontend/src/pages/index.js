export default function Home() {return (<main style={{padding:20}}><h1>Multimedia AI — Frontend</h1><p>Prompt simple.</p></main>)}
