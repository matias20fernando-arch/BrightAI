import os,time,json,redis
REDIS_URL=os.environ.get('REDIS_URL','redis://localhost:6379')
r=redis.from_url(REDIS_URL)
print('Worker started...')
while True:
    job_raw=r.rpop('jobs')
    if job_raw:
        job=json.loads(job_raw)
        print('Processing job:',job['id'])
        time.sleep(2)
        print('Job done:',job['id'])
    else:
        time.sleep(1)
