// Simplified API
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const redis = require('redis');
const app = express();
app.use(bodyParser.json());
const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
const client = redis.createClient({ url: REDIS_URL });
client.connect().catch(console.error);
app.post('/api/generate/image', async (req, res) => {
  const id = uuidv4();
  const job = { id, type: 'image', payload: req.body, status: 'queued' };
  await client.lPush('jobs', JSON.stringify(job));
  res.json({ jobId: id });
});
app.get('/api/job/:id', async (req, res) => {
  res.json({ id: req.params.id, status: 'queued' });
});
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Backend listening on ${port}`));
